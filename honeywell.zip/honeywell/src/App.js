import logo from './logo.svg';
import './App.css';
import { City } from './components/city';

function App() {
  return (
    <div className="App">
      <City />
    </div>
  );
}

export default App;
